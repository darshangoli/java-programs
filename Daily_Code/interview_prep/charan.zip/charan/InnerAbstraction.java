package charan;

interface InnerAbstraction {
    public int sub();
    public int sub(int a, int b);
}
