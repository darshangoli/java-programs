package charan;

class Dog{
    public void bark(){
        System.out.println("Bow Bow");
    }
}
