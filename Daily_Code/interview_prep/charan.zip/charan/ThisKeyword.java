package charan;

public class ThisKeyword {
    int count;

    public int increment(int count){
        this.count += 1;
        return count;
    }
}
